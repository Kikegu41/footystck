import { useState } from 'react';
import { Header } from './components/Header';
import { ProductCard, Product } from './components/ProductCard';
import { PersonalizationDialog, CartItem } from './components/PersonalizationDialog';
import { ShoppingCart } from './components/ShoppingCart';
import { LeagueMenu } from './components/LeagueMenu';
import { SoccerBall } from './components/SoccerBall';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';
import { Badge } from './components/ui/badge';
import { X } from 'lucide-react';
import { Button } from './components/ui/button';

// Mock data for products - Complete coverage of Top 5 European Leagues
const products: Product[] = [
  // LA LIGA - España
  { id: '1', name: 'Camiseta Local 2025/26', team: 'Real Madrid', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '2', name: 'Camiseta Visitante 2025/26', team: 'Real Madrid', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1614453966169-fd72db98e20f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjBibGFja3xlbnwxfHx8fDE3NjI0MzQwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '3', name: 'Camiseta Retro 2002', team: 'Real Madrid', league: 'La Liga', price: 24.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2002', isRetro: true, available: true },
  
  { id: '4', name: 'Camiseta Local 2025/26', team: 'FC Barcelona', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '5', name: 'Camiseta Visitante 2025/26', team: 'FC Barcelona', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1761891956889-8610f900dc2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGplcnNleSUyMHllbGxvd3xlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '6', name: 'Camiseta Retro 2009', team: 'FC Barcelona', league: 'La Liga', price: 24.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2009', isRetro: true, available: true },
  
  { id: '7', name: 'Camiseta Local 2025/26', team: 'Atlético Madrid', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '8', name: 'Camiseta Local 2024/26', team: 'Sevilla FC', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '9', name: 'Camiseta Local 2024/26', team: 'Real Betis', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1695194644164-613941d556eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBraXQlMjBncmVlbnxlbnwxfHx8fDE3NjI0NDE0MzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '10', name: 'Camiseta Local 2024/26', team: 'Valencia CF', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '11', name: 'Camiseta Local 2024/26', team: 'Villarreal CF', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1761891956889-8610f900dc2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGplcnNleSUyMHllbGxvd3xlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '12', name: 'Camiseta Local 2024/26', team: 'Athletic Bilbao', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '13', name: 'Camiseta Local 2024/26', team: 'Real Sociedad', league: 'La Liga', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  
  // PREMIER LEAGUE - Inglaterra
  { id: '14', name: 'Camiseta Local 2024/26', team: 'Manchester City', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '15', name: 'Camiseta Visitante 2024/26', team: 'Manchester City', league: 'Premier League', price: 24.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  
  { id: '16', name: 'Camiseta Local 2024/26', team: 'Liverpool FC', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '17', name: 'Camiseta Retro 2005', team: 'Liverpool FC', league: 'Premier League', price: 24.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2005', isRetro: true, available: true },
  
  { id: '18', name: 'Camiseta Local 2024/26', team: 'Arsenal FC', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '19', name: 'Camiseta Retro 2004', team: 'Arsenal FC', league: 'Premier League', price: 24.99, image: 'https://images.unsplash.com/photo-1761891956889-8610f900dc2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGplcnNleSUyMHllbGxvd3xlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2004', isRetro: true, available: true },
  
  { id: '20', name: 'Camiseta Local 2024/26', team: 'Manchester United', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '21', name: 'Camiseta Retro 1999', team: 'Manchester United', league: 'Premier League', price: 24.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '1999', isRetro: true, available: true },
  
  { id: '22', name: 'Camiseta Local 2024/26', team: 'Chelsea FC', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '23', name: 'Camiseta Local 2024/26', team: 'Tottenham Hotspur', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '24', name: 'Camiseta Local 2024/26', team: 'Newcastle United', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1614453966169-fd72db98e20f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjBibGFja3xlbnwxfHx8fDE3NjI0MzQwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '25', name: 'Camiseta Local 2024/26', team: 'Aston Villa', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '26', name: 'Camiseta Local 2024/26', team: 'West Ham United', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '27', name: 'Camiseta Local 2024/26', team: 'Brighton & Hove Albion', league: 'Premier League', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  
  // SERIE A - Italia
  { id: '28', name: 'Camiseta Local 2024/26', team: 'Juventus', league: 'Serie A', price: 19.99, image: 'https://images.unsplash.com/photo-1614453966169-fd72db98e20f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjBibGFja3xlbnwxfHx8fDE3NjI0MzQwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '29', name: 'Camiseta Retro 1996', team: 'Juventus', league: 'Serie A', price: 24.99, image: 'https://images.unsplash.com/photo-1614453966169-fd72db98e20f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjBibGFja3xlbnwxfHx8fDE3NjI0MzQwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '1996', isRetro: true, available: true },
  
  { id: '30', name: 'Camiseta Local 2024/26', team: 'Inter Milan', league: 'Serie A', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '31', name: 'Camiseta Retro 2010', team: 'Inter Milan', league: 'Serie A', price: 24.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2010', isRetro: true, available: true },
  
  { id: '32', name: 'Camiseta Local 2024/26', team: 'AC Milan', league: 'Serie A', price: 81.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '33', name: 'Camiseta Retro 2007', team: 'AC Milan', league: 'Serie A', price: 24.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2007', isRetro: true, available: true },
  
  { id: '34', name: 'Camiseta Local 2024/26', team: 'SSC Napoli', league: 'Serie A', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '35', name: 'Camiseta Retro 1990', team: 'SSC Napoli', league: 'Serie A', price: 24.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '1990', isRetro: true, available: true },
  
  { id: '36', name: 'Camiseta Local 2024/26', team: 'AS Roma', league: 'Serie A', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '37', name: 'Camiseta Local 2024/26', team: 'SS Lazio', league: 'Serie A', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '38', name: 'Camiseta Local 2024/26', team: 'Atalanta BC', league: 'Serie A', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '39', name: 'Camiseta Local 2024/26', team: 'ACF Fiorentina', league: 'Serie A', price: 19.99, image: 'https://images.unsplash.com/photo-1614453966169-fd72db98e20f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjBibGFja3xlbnwxfHx8fDE3NjI0MzQwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  
  // BUNDESLIGA - Alemania
  { id: '40', name: 'Camiseta Local 2024/26', team: 'Bayern Munich', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '41', name: 'Camiseta Retro 2013', team: 'Bayern Munich', league: 'Bundesliga', price: 24.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2013', isRetro: true, available: true },
  
  { id: '42', name: 'Camiseta Local 2024/26', team: 'Borussia Dortmund', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1761891956889-8610f900dc2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGplcnNleSUyMHllbGxvd3xlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '43', name: 'Camiseta Retro 1997', team: 'Borussia Dortmund', league: 'Bundesliga', price: 24.99, image: 'https://images.unsplash.com/photo-1761891956889-8610f900dc2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGplcnNleSUyMHllbGxvd3xlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '1997', isRetro: true, available: true },
  
  { id: '44', name: 'Camiseta Local 2024/26', team: 'RB Leipzig', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '45', name: 'Camiseta Local 2024/26', team: 'Bayer Leverkusen', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '46', name: 'Camiseta Local 2024/26', team: 'Union Berlin', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '47', name: 'Camiseta Local 2024/26', team: 'Eintracht Frankfurt', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1614453966169-fd72db98e20f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjBibGFja3xlbnwxfHx8fDE3NjI0MzQwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '48', name: 'Camiseta Local 2024/26', team: 'VfB Stuttgart', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '49', name: 'Camiseta Local 2024/26', team: 'Borussia Mönchengladbach', league: 'Bundesliga', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  
  // LIGUE 1 - Francia
  { id: '50', name: 'Camiseta Local 2024/26', team: 'Paris Saint-Germain', league: 'Ligue 1', price: 19.99, image: 'https://images.unsplash.com/photo-1601087373050-0cb2aa6bf7ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMHNoaXJ0JTIwYmx1ZXxlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '51', name: 'Camiseta Visitante 2024/26', team: 'Paris Saint-Germain', league: 'Ligue 1', price: 24.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2024/26', isRetro: false, available: true },
  
  { id: '52', name: 'Camiseta Local 2024/26', team: 'Olympique Marseille', league: 'Ligue 1', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '53', name: 'Camiseta Retro 1993', team: 'Olympique Marseille', league: 'Ligue 1', price: 24.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '1993', isRetro: true, available: true },
  
  { id: '54', name: 'Camiseta Local 2024/26', team: 'AS Monaco', league: 'Ligue 1', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '55', name: 'Camiseta Local 2024/26', team: 'Olympique Lyon', league: 'Ligue 1', price: 19.99, image: 'https://images.unsplash.com/photo-1595853663378-fc2879e00d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NjZXIlMjBqZXJzZXklMjB3aGl0ZXxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '56', name: 'Camiseta Local 2024/26', team: 'Lille OSC', league: 'Ligue 1', price: 14.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '57', name: 'Camiseta Local 2024/26', team: 'OGC Nice', league: 'Ligue 1', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '58', name: 'Camiseta Local 2024/26', team: 'RC Lens', league: 'Ligue 1', price: 19.99, image: 'https://images.unsplash.com/photo-1761891956889-8610f900dc2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGplcnNleSUyMHllbGxvd3xlbnwxfHx8fDE3NjI0NDE0MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
  { id: '59', name: 'Camiseta Local 2024/26', team: 'Stade Rennais', league: 'Ligue 1', price: 19.99, image: 'https://images.unsplash.com/photo-1584329492930-56bb3e10d492?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb290YmFsbCUyMGtpdCUyMHJlZHxlbnwxfHx8fDE3NjI0NDE0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral', season: '2025/26', isRetro: false, available: true },
];

export default function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('featured');
  const [selectedLeague, setSelectedLeague] = useState<string | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<string | null>(null);

  const handleCustomize = (product: Product) => {
    setSelectedProduct(product);
    setIsDialogOpen(true);
  };

  const handleAddToCart = (item: CartItem) => {
    setCartItems([...cartItems, item]);
    toast.success('Producto añadido al carrito', {
      description: `${item.product.team} - Talla ${item.size}`,
    });
  };

  const handleRemoveItem = (index: number) => {
    const newItems = cartItems.filter((_, i) => i !== index);
    setCartItems(newItems);
    toast.success('Producto eliminado del carrito');
  };

  const filterAndSortProducts = (products: Product[], isRetro: boolean) => {
    let filtered = products.filter(p => p.isRetro === isRetro);
    
    // Filter by league
    if (selectedLeague && !selectedTeam) {
      filtered = filtered.filter(p => p.league === selectedLeague);
    }
    
    // Filter by team
    if (selectedTeam) {
      filtered = filtered.filter(p => p.team === selectedTeam);
    }
    
    if (searchQuery) {
      filtered = filtered.filter(p =>
        p.team.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.league.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    switch (sortBy) {
      case 'price-asc':
        return filtered.sort((a, b) => a.price - b.price);
      case 'price-desc':
        return filtered.sort((a, b) => b.price - a.price);
      case 'name':
        return filtered.sort((a, b) => a.team.localeCompare(b.team));
      default:
        return filtered;
    }
  };

  const currentProducts = filterAndSortProducts(products, false);
  const retroProducts = filterAndSortProducts(products, true);

  return (
    <div className="min-h-screen bg-gray-50 relative">
      {/* Soccer field striped background */}
      <div 
        className="fixed inset-0 -z-10" 
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, #15803d 0px, #15803d 60px, #16a34a 60px, #16a34a 120px)',
          opacity: 0.15
        }}
      />
      
      {/* Animated soccer ball */}
      <SoccerBall />
      <Header
        cartCount={cartItems.length}
        onCartClick={() => setIsCartOpen(true)}
        onMenuClick={() => setIsMenuOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="mb-2">Nuestra Colección</h2>
          <p className="text-gray-600">
            Descubre las mejores camisetas de fútbol con opciones de personalización
          </p>
        </div>

        {(selectedLeague || selectedTeam) && (
          <div className="mb-6 flex items-center gap-2 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="text-sm">Filtrando por:</span>
            {selectedTeam ? (
              <Badge className="bg-blue-600">
                {selectedTeam}
                <button
                  className="ml-2 hover:bg-blue-700 rounded-full"
                  onClick={() => {
                    setSelectedTeam(null);
                    setSelectedLeague(null);
                  }}
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ) : selectedLeague ? (
              <Badge className="bg-blue-600">
                {selectedLeague}
                <button
                  className="ml-2 hover:bg-blue-700 rounded-full"
                  onClick={() => setSelectedLeague(null)}
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ) : null}
            <Button
              variant="ghost"
              size="sm"
              className="ml-auto text-xs"
              onClick={() => {
                setSelectedLeague(null);
                setSelectedTeam(null);
              }}
            >
              Limpiar filtros
            </Button>
          </div>
        )}

        <div className="mb-6 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Ordenar por:</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Destacados</SelectItem>
                <SelectItem value="price-asc">Precio: Menor a Mayor</SelectItem>
                <SelectItem value="price-desc">Precio: Mayor a Menor</SelectItem>
                <SelectItem value="name">Nombre A-Z</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="text-sm text-gray-600">
            {currentProducts.length + retroProducts.length} productos encontrados
          </div>
        </div>

        <Tabs defaultValue="current" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2 mb-8">
            <TabsTrigger value="current">Actuales</TabsTrigger>
            <TabsTrigger value="retro">Retro</TabsTrigger>
          </TabsList>

          <TabsContent value="current" className="space-y-6">
            {currentProducts.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                No se encontraron productos
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {currentProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onCustomize={handleCustomize}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="retro" className="space-y-6">
            {retroProducts.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                No se encontraron productos retro
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {retroProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onCustomize={handleCustomize}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <PersonalizationDialog
        product={selectedProduct}
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        onAddToCart={handleAddToCart}
      />

      <ShoppingCart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onRemoveItem={handleRemoveItem}
      />

      <LeagueMenu
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        products={products}
        onLeagueSelect={setSelectedLeague}
        onTeamSelect={setSelectedTeam}
        selectedLeague={selectedLeague}
        selectedTeam={selectedTeam}
      />

      <Toaster />
    </div>
  );
}
