import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

export interface Product {
  id: string;
  name: string;
  team: string;
  league: string;
  price: number;
  image: string;
  season: string;
  isRetro: boolean;
  available: boolean;
}

interface ProductCardProps {
  product: Product;
  onCustomize: (product: Product) => void;
}

export function ProductCard({ product, onCustomize }: ProductCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <CardContent className="p-0">
        <div className="relative aspect-square bg-gray-50">
          <ImageWithFallback
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
          {product.isRetro && (
            <Badge className="absolute top-2 left-2 bg-amber-500">
              Retro
            </Badge>
          )}
          {!product.available && (
            <Badge className="absolute top-2 right-2 bg-red-500">
              Agotado
            </Badge>
          )}
        </div>
        
        <div className="p-4 space-y-3">
          <div>
            <h3 className="tracking-tight">{product.team}</h3>
            <p className="text-sm text-gray-500">{product.name}</p>
            <p className="text-xs text-gray-400 mt-1">{product.league} • {product.season}</p>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-blue-600">€{product.price.toFixed(2)}</span>
            <Button 
              onClick={() => onCustomize(product)}
              disabled={!product.available}
              size="sm"
            >
              {product.available ? 'Personalizar' : 'No disponible'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
