import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from './ui/sheet';
import { Button } from './ui/button';
import { CartItem } from './PersonalizationDialog';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Trash2, ShoppingBag } from 'lucide-react';
import { Separator } from './ui/separator';

interface ShoppingCartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemoveItem: (index: number) => void;
}

export function ShoppingCart({ isOpen, onClose, items, onRemoveItem }: ShoppingCartProps) {
  const total = items.reduce((sum, item) => {
    const personalizationCost = (item.playerName || item.playerNumber) ? 12 : 0;
    return sum + (item.product.price + personalizationCost) * item.quantity;
  }, 0);

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>Carrito de Compras</SheetTitle>
          <SheetDescription>
            {items.length === 0 
              ? 'Tu carrito está vacío' 
              : `${items.length} artículo${items.length > 1 ? 's' : ''} en tu carrito`}
          </SheetDescription>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[60vh] text-gray-400">
            <ShoppingBag className="w-16 h-16 mb-4" />
            <p>No hay productos en el carrito</p>
          </div>
        ) : (
          <>
            <div className="mt-8 space-y-4 flex-1 overflow-y-auto max-h-[60vh]">
              {items.map((item, index) => {
                const personalizationCost = (item.playerName || item.playerNumber) ? 12 : 0;
                const itemTotal = (item.product.price + personalizationCost) * item.quantity;
                
                return (
                  <div key={index} className="flex gap-4 p-4 bg-gray-50 rounded-lg">
                    <div className="w-20 h-20 bg-white rounded overflow-hidden flex-shrink-0">
                      <ImageWithFallback
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm truncate">{item.product.team}</h4>
                      <p className="text-xs text-gray-500 truncate">{item.product.name}</p>
                      
                      <div className="mt-2 space-y-1">
                        <p className="text-xs text-gray-600">Talla: {item.size}</p>
                        {item.playerName && (
                          <p className="text-xs text-gray-600">Nombre: {item.playerName}</p>
                        )}
                        {item.playerNumber && (
                          <p className="text-xs text-gray-600">Número: {item.playerNumber}</p>
                        )}
                        <p className="text-xs text-gray-600">Cantidad: {item.quantity}</p>
                      </div>
                      
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-sm text-blue-600">€{itemTotal.toFixed(2)}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => onRemoveItem(index)}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-6 space-y-4">
              <Separator />
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span>€{total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Envío</span>
                  <span className="text-green-600">Gratis</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span>Total</span>
                  <span className="text-blue-600">€{total.toFixed(2)}</span>
                </div>
              </div>

              <Button className="w-full" size="lg">
                Proceder al pago
              </Button>
              <Button variant="outline" className="w-full" onClick={onClose}>
                Seguir comprando
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
