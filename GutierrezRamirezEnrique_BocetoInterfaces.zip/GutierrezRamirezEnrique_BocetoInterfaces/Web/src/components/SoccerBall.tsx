import { motion } from 'motion/react';

export function SoccerBall() {
  return (
    <motion.div
      className="fixed top-8 right-8 z-10 pointer-events-none"
      animate={{ rotate: 360 }}
      transition={{
        duration: 4,
        repeat: Infinity,
        ease: "linear"
      }}
    >
      <svg
        width="80"
        height="80"
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* White circle base */}
        <circle cx="50" cy="50" r="48" fill="white" stroke="#e5e7eb" strokeWidth="2" />
        
        {/* Black pentagon in center */}
        <path
          d="M50 15 L65 30 L60 48 L40 48 L35 30 Z"
          fill="black"
        />
        
        {/* Black pentagon top right */}
        <path
          d="M65 30 L82 32 L85 48 L75 58 L60 48 Z"
          fill="black"
        />
        
        {/* Black pentagon top left */}
        <path
          d="M35 30 L18 32 L15 48 L25 58 L40 48 Z"
          fill="black"
        />
        
        {/* Black pentagon bottom right */}
        <path
          d="M60 48 L75 58 L70 75 L55 78 L50 65 Z"
          fill="black"
        />
        
        {/* Black pentagon bottom left */}
        <path
          d="M40 48 L25 58 L30 75 L45 78 L50 65 Z"
          fill="black"
        />
        
        {/* Gray stitching lines */}
        <path d="M50 15 L65 30 M65 30 L82 32 M35 30 L18 32 M60 48 L75 58 M40 48 L25 58 M50 65 L55 78 M50 65 L45 78" 
          stroke="#9ca3af" 
          strokeWidth="1" 
          fill="none"
        />
      </svg>
    </motion.div>
  );
}
