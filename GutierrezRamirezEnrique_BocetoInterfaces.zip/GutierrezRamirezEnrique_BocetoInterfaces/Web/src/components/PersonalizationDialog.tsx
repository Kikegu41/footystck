import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Product } from './ProductCard';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Plus, Minus } from 'lucide-react';

export interface CartItem {
  product: Product;
  size: string;
  playerName: string;
  playerNumber: string;
  quantity: number;
}

interface PersonalizationDialogProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
}

const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export function PersonalizationDialog({ 
  product, 
  isOpen, 
  onClose,
  onAddToCart 
}: PersonalizationDialogProps) {
  const [size, setSize] = useState('M');
  const [playerName, setPlayerName] = useState('');
  const [playerNumber, setPlayerNumber] = useState('');
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    if (!product) return;
    
    onAddToCart({
      product,
      size,
      playerName,
      playerNumber,
      quantity,
    });
    
    // Reset form
    setSize('M');
    setPlayerName('');
    setPlayerNumber('');
    setQuantity(1);
    onClose();
  };

  if (!product) return null;

  const personalizationCost = (playerName || playerNumber) ? 12 : 0;
  const totalPrice = (product.price + personalizationCost) * quantity;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Personalizar Camiseta</DialogTitle>
          <DialogDescription>
            {product.team} - {product.name}
          </DialogDescription>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="aspect-square bg-gray-50 rounded-lg overflow-hidden">
            <ImageWithFallback
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-4">
            <div>
              <Label>Talla *</Label>
              <RadioGroup value={size} onValueChange={setSize} className="grid grid-cols-3 gap-2 mt-2">
                {sizes.map((s) => (
                  <div key={s}>
                    <RadioGroupItem
                      value={s}
                      id={`size-${s}`}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={`size-${s}`}
                      className="flex items-center justify-center rounded-md border-2 border-gray-200 bg-white p-3 hover:bg-gray-50 peer-data-[state=checked]:border-blue-600 peer-data-[state=checked]:bg-blue-50 cursor-pointer"
                    >
                      {s}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="playerName">Nombre del jugador (opcional)</Label>
              <Input
                id="playerName"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value.toUpperCase())}
                placeholder="GARCÍA"
                maxLength={15}
                className="mt-2"
              />
              <p className="text-xs text-gray-500 mt-1">Máximo 15 caracteres</p>
            </div>

            <div>
              <Label htmlFor="playerNumber">Número (opcional)</Label>
              <Input
                id="playerNumber"
                value={playerNumber}
                onChange={(e) => setPlayerNumber(e.target.value)}
                placeholder="10"
                type="number"
                min="0"
                max="99"
                className="mt-2"
              />
            </div>

            <div>
              <Label>Cantidad</Label>
              <div className="flex items-center gap-2 mt-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                >
                  <Minus className="w-4 h-4" />
                </Button>
                <span className="w-12 text-center">{quantity}</span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.min(10, quantity + 1))}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="pt-4 border-t space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Camiseta</span>
                <span>€{(product.price * quantity).toFixed(2)}</span>
              </div>
              {personalizationCost > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Personalización</span>
                  <span>€{(personalizationCost * quantity).toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between pt-2 border-t">
                <span>Total</span>
                <span className="text-blue-600">€{totalPrice.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleAddToCart}>
            Añadir al carrito
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
