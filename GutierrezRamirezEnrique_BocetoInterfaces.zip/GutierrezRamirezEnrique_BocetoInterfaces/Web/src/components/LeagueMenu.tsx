import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from './ui/sheet';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Product } from './ProductCard';
import { X } from 'lucide-react';

interface LeagueMenuProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onLeagueSelect: (league: string | null) => void;
  onTeamSelect: (team: string | null) => void;
  selectedLeague: string | null;
  selectedTeam: string | null;
}

export function LeagueMenu({
  isOpen,
  onClose,
  products,
  onLeagueSelect,
  onTeamSelect,
  selectedLeague,
  selectedTeam,
}: LeagueMenuProps) {
  // Separar productos actuales y retro
  const currentProducts = products.filter(p => !p.isRetro);
  const retroProducts = products.filter(p => p.isRetro);

  // Función para organizar productos por liga y equipo
  const organizeByLeague = (productList: Product[]) => {
    const leaguesData = productList.reduce((acc, product) => {
      if (!acc[product.league]) {
        acc[product.league] = new Set<string>();
      }
      acc[product.league].add(product.team);
      return acc;
    }, {} as Record<string, Set<string>>);

    return Object.keys(leaguesData).sort((a, b) => 
      a.localeCompare(b, 'es')
    ).map(league => ({
      league,
      teams: Array.from(leaguesData[league]).sort((a, b) => a.localeCompare(b, 'es'))
    }));
  };

  const currentLeagues = organizeByLeague(currentProducts);
  const retroLeagues = organizeByLeague(retroProducts);

  const handleLeagueClick = (league: string) => {
    if (selectedLeague === league) {
      onLeagueSelect(null);
      onTeamSelect(null);
    } else {
      onLeagueSelect(league);
      onTeamSelect(null);
    }
  };

  const handleTeamClick = (team: string, league: string) => {
    if (selectedTeam === team) {
      onTeamSelect(null);
      onLeagueSelect(null);
    } else {
      onTeamSelect(team);
      onLeagueSelect(league);
    }
  };

  const handleClearFilters = () => {
    onLeagueSelect(null);
    onTeamSelect(null);
  };

  // Renderizar sección de ligas
  const renderLeagueSection = (leagueList: { league: string; teams: string[] }[], productList: Product[]) => {
    return leagueList.map(({ league, teams }) => {
      const leagueProductCount = productList.filter(p => p.league === league).length;

      return (
        <AccordionItem key={league} value={league} className="border-none">
          <AccordionTrigger className="hover:no-underline py-2 px-3 hover:bg-gray-50 rounded">
            <div className="flex items-center justify-between w-full pr-4">
              <span
                className={`text-sm ${
                  selectedLeague === league && !selectedTeam
                    ? 'text-blue-600'
                    : ''
                }`}
              >
                {league}
              </span>
              <Badge variant="secondary" className="ml-2 text-xs">
                {leagueProductCount}
              </Badge>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-1 pl-4 mt-1">
              <Button
                variant="ghost"
                className={`w-full justify-start text-xs h-8 ${
                  selectedLeague === league && !selectedTeam
                    ? 'bg-blue-50 text-blue-600'
                    : ''
                }`}
                onClick={() => handleLeagueClick(league)}
              >
                Toda la liga
              </Button>
              {teams.map((team) => {
                const teamProductCount = productList.filter(
                  (p) => p.team === team
                ).length;

                return (
                  <Button
                    key={team}
                    variant="ghost"
                    className={`w-full justify-between text-xs h-8 ${
                      selectedTeam === team
                        ? 'bg-blue-50 text-blue-600'
                        : ''
                    }`}
                    onClick={() => handleTeamClick(team, league)}
                  >
                    <span className="truncate">{team}</span>
                    <Badge variant="outline" className="ml-2 text-xs">
                      {teamProductCount}
                    </Badge>
                  </Button>
                );
              })}
            </div>
          </AccordionContent>
        </AccordionItem>
      );
    });
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Menú de Categorías</SheetTitle>
          <SheetDescription>
            Explora por temporadas, ligas y equipos
          </SheetDescription>
        </SheetHeader>

        {(selectedLeague || selectedTeam) && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-600">Filtro activo:</p>
              <p className="text-sm">
                {selectedTeam || selectedLeague}
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearFilters}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        )}

        <div className="mt-6 overflow-y-auto max-h-[calc(100vh-200px)]">
          <Accordion type="single" collapsible className="w-full space-y-2">
            {/* Temporada 25/26 (Actuales) */}
            <AccordionItem value="current" className="border rounded-lg">
              <AccordionTrigger className="hover:no-underline px-4">
                <div className="flex items-center justify-between w-full pr-4">
                  <div className="flex items-center gap-2">
                    <span>Temporada 25/26</span>
                  </div>
                  <Badge className="bg-green-600">
                    {currentProducts.length}
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-2 pb-2">
                {currentLeagues.length > 0 ? (
                  <Accordion type="single" collapsible className="w-full">
                    {renderLeagueSection(currentLeagues, currentProducts)}
                  </Accordion>
                ) : (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No hay productos disponibles
                  </p>
                )}
              </AccordionContent>
            </AccordionItem>

            {/* Retro */}
            <AccordionItem value="retro" className="border rounded-lg">
              <AccordionTrigger className="hover:no-underline px-4">
                <div className="flex items-center justify-between w-full pr-4">
                  <div className="flex items-center gap-2">
                    <span>Retro</span>
                  </div>
                  <Badge className="bg-amber-600">
                    {retroProducts.length}
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-2 pb-2">
                {retroLeagues.length > 0 ? (
                  <Accordion type="single" collapsible className="w-full">
                    {renderLeagueSection(retroLeagues, retroProducts)}
                  </Accordion>
                ) : (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No hay productos retro disponibles
                  </p>
                )}
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>

        <div className="mt-6 pt-4 border-t">
          <Button variant="outline" className="w-full" onClick={onClose}>
            Cerrar menú
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}