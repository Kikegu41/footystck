
  # Tienda de Camisetas de Fútbol

  This is a code bundle for Tienda de Camisetas de Fútbol. The original project is available at https://www.figma.com/design/hK4kek7VuHM8xMcncE9l1L/Tienda-de-Camisetas-de-F%C3%BAtbol.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  